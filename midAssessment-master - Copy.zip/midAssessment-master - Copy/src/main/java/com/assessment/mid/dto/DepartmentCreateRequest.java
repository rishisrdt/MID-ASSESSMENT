package com.assessment.mid.dto;

import jakarta.validation.constraints.NotBlank;

import java.util.ArrayList;
import java.util.List;

public class DepartmentCreateRequest {
    @NotBlank
    private String deptName;

    // (Optional) create-and-assign employees during dept creation
    private List<EmployeeCreateRequest> employees = new ArrayList<>();

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public List<EmployeeCreateRequest> getEmployees() {
        return employees;
    }

    public void setEmployees(List<EmployeeCreateRequest> employees) {
        this.employees = employees;
    }
}
