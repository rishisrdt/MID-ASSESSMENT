package com.assessment.mid.controller;

import com.assessment.mid.dto.ChangeDepartmentRequest;
import com.assessment.mid.dto.EmployeeResponse;
import com.assessment.mid.dto.SimpleMessageResponse;
import com.assessment.mid.entity.Employee;
import com.assessment.mid.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    private final EmployeeService employeeService;
    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    // Change the department of an employee (creates a new "current" assignment)
    @PutMapping("/{empId}/department")
    public ResponseEntity<SimpleMessageResponse> changeDepartment(@PathVariable Long empId,
                                                                  @Valid @RequestBody ChangeDepartmentRequest req) {
        employeeService.changeDepartment(empId, req.getDepartmentId());
        return ResponseEntity.ok(new SimpleMessageResponse("Department changed successfully"));
    }

    // Get the latest department for an employee (answers the scenario)
    @GetMapping("/{empId}/department/latest")
    public ResponseEntity<EmployeeResponse> latestDepartment(@PathVariable Long empId) {
        return ResponseEntity.ok(employeeService.getEmployeeWithLatestDept(empId));
    }
}

