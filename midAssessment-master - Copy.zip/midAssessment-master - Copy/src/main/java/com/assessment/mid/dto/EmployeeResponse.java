package com.assessment.mid.dto;

public class EmployeeResponse {
    private Long empId;
    private String empName;
    private String empEmail;
    private Long latestDeptId;     // null if none
    private String latestDeptName; // null if none

    public Long getEmpId() { return empId; }
    public void setEmpId(Long empId) { this.empId = empId; }
    public String getEmpName() { return empName; }
    public void setEmpName(String empName) { this.empName = empName; }
    public String getEmpEmail() { return empEmail; }
    public void setEmpEmail(String empEmail) { this.empEmail = empEmail; }
    public Long getLatestDeptId() { return latestDeptId; }
    public void setLatestDeptId(Long latestDeptId) { this.latestDeptId = latestDeptId; }
    public String getLatestDeptName() { return latestDeptName; }
    public void setLatestDeptName(String latestDeptName) { this.latestDeptName = latestDeptName; }
}
