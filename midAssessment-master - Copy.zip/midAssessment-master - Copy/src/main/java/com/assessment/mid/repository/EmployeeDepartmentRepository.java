package com.assessment.mid.repository;

import com.assessment.mid.entity.Employee;
import com.assessment.mid.entity.EmployeeDepartment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface EmployeeDepartmentRepository extends JpaRepository<EmployeeDepartment, Long> {

    // Latest assignment by timestamp
    Optional<EmployeeDepartment> findTopByEmployeeOrderByAssignedAtDesc(Employee employee);

    // Current assignment (flag)
    Optional<EmployeeDepartment> findByEmployee_EmpIdAndCurrentIsTrue(Long empId);

    // All current employees under a department
    @Query("""
           SELECT ed FROM EmployeeDepartment ed
           JOIN FETCH ed.employee e
           WHERE ed.department.deptId = :deptId
             AND ed.current = true
           """)
    List<EmployeeDepartment> findCurrentByDepartmentId(Long deptId);
}
