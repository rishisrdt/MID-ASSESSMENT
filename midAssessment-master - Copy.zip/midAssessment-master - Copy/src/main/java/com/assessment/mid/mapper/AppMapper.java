package com.assessment.mid.mapper;

import com.assessment.mid.dto.DepartmentResponse;
import com.assessment.mid.dto.EmployeeResponse;
import com.assessment.mid.entity.Department;
import com.assessment.mid.entity.Employee;
import com.assessment.mid.entity.EmployeeDepartment;

import java.util.List;
import java.util.Optional;

public class AppMapper {

    public static EmployeeResponse toEmployeeResponse(Employee e, Optional<EmployeeDepartment> latest) {
        EmployeeResponse dto = new EmployeeResponse();
        dto.setEmpId(e.getEmpId());
        dto.setEmpName(e.getEmpName());
        dto.setEmpEmail(e.getEmpEmail());
        if (latest.isPresent()) {
            EmployeeDepartment ed = latest.get();
            dto.setLatestDeptId(ed.getDepartment().getDeptId());
            dto.setLatestDeptName(ed.getDepartment().getDeptName());
        }
        return dto;
    }

    public static DepartmentResponse toDepartmentResponse(Department d, List<EmployeeResponse> emps) {
        DepartmentResponse dto = new DepartmentResponse();
        dto.setDeptId(d.getDeptId());
        dto.setDeptName(d.getDeptName());
        dto.setEmployees(emps);
        return dto;
    }
}
