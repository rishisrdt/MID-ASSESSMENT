package com.assessment.mid.service;

import com.assessment.mid.dto.DepartmentCreateRequest;
import com.assessment.mid.dto.DepartmentResponse;
import com.assessment.mid.dto.EmployeeCreateRequest;
import com.assessment.mid.dto.EmployeeResponse;
import com.assessment.mid.entity.Department;
import com.assessment.mid.entity.Employee;
import com.assessment.mid.entity.EmployeeDepartment;
import com.assessment.mid.mapper.AppMapper;
import com.assessment.mid.repository.DepartmentRepository;
import com.assessment.mid.repository.EmployeeDepartmentRepository;
import com.assessment.mid.repository.EmployeeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class DepartmentService {

    private final DepartmentRepository departmentRepository;
    private final EmployeeRepository employeeRepository;
    private final EmployeeDepartmentRepository employeeDepartmentRepository;

    public DepartmentService(DepartmentRepository departmentRepository,
                             EmployeeRepository employeeRepository,
                             EmployeeDepartmentRepository employeeDepartmentRepository) {
        this.departmentRepository = departmentRepository;
        this.employeeRepository = employeeRepository;
        this.employeeDepartmentRepository = employeeDepartmentRepository;
    }

    @Transactional
    public DepartmentResponse createDepartmentWithEmployees(DepartmentCreateRequest req) {
        if (departmentRepository.existsByDeptNameIgnoreCase(req.getDeptName())) {
            throw new IllegalArgumentException("Department with same name already exists");
        }

        Department dept = new Department(req.getDeptName());
        departmentRepository.save(dept);

        // Optionally create employees and assign them as "current"
        for (EmployeeCreateRequest eReq : req.getEmployees()) {
            if (employeeRepository.existsByEmpEmailIgnoreCase(eReq.getEmpEmail())) {
                // Simple guard: skip or throw. Here we throw to keep unique.
                throw new IllegalArgumentException("Employee email already exists: " + eReq.getEmpEmail());
            }
            Employee emp = new Employee(eReq.getEmpName(), eReq.getEmpEmail());
            employeeRepository.save(emp);

            EmployeeDepartment assignment = new EmployeeDepartment(emp, dept, Instant.now(), true);
            employeeDepartmentRepository.save(assignment);
        }

        // Build response including current employees
        List<EmployeeDepartment> currents = employeeDepartmentRepository.findCurrentByDepartmentId(dept.getDeptId());
        List<EmployeeResponse> empDtos = new ArrayList<>();
        for (EmployeeDepartment ed : currents) {
            empDtos.add(AppMapper.toEmployeeResponse(ed.getEmployee(), Optional.of(ed)));
        }

        return AppMapper.toDepartmentResponse(dept, empDtos);
    }

    @Transactional(readOnly = true)
    public List<EmployeeResponse> getCurrentEmployeesInDepartment(Long deptId) {
        Department dept = departmentRepository.findById(deptId)
                .orElseThrow(() -> new IllegalArgumentException("Department not found"));

        List<EmployeeDepartment> currents = employeeDepartmentRepository.findCurrentByDepartmentId(dept.getDeptId());
        List<EmployeeResponse> out = new ArrayList<>();
        for (EmployeeDepartment ed : currents) {
            out.add(AppMapper.toEmployeeResponse(ed.getEmployee(), Optional.of(ed)));
        }
        return out;
    }
}
