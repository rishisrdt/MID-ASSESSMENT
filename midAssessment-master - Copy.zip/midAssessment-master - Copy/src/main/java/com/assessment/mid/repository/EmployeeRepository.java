package com.assessment.mid.repository;
import com.assessment.mid.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    Optional<Employee> findByEmpEmailIgnoreCase(String email);
    boolean existsByEmpEmailIgnoreCase(String email);
}
