package com.assessment.mid.service;

import com.assessment.mid.dto.EmployeeResponse;
import com.assessment.mid.entity.Department;
import com.assessment.mid.entity.Employee;
import com.assessment.mid.entity.EmployeeDepartment;
import com.assessment.mid.mapper.AppMapper;
import com.assessment.mid.repository.DepartmentRepository;
import com.assessment.mid.repository.EmployeeDepartmentRepository;
import com.assessment.mid.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;
    private final EmployeeDepartmentRepository employeeDepartmentRepository;

    public EmployeeService(EmployeeRepository employeeRepository,
                           DepartmentRepository departmentRepository,
                           EmployeeDepartmentRepository employeeDepartmentRepository) {
        this.employeeRepository = employeeRepository;
        this.departmentRepository = departmentRepository;
        this.employeeDepartmentRepository = employeeDepartmentRepository;
    }

    @Transactional
    public void changeDepartment(Long empId, Long deptId) {
        Employee emp = employeeRepository.findById(empId)
                .orElseThrow(() -> new IllegalArgumentException("Employee not found"));
        Department dept = departmentRepository.findById(deptId)
                .orElseThrow(() -> new IllegalArgumentException("Department not found"));

        // Set previous current assignment (if any) to false
        Optional<EmployeeDepartment> currentOpt = employeeDepartmentRepository
                .findByEmployee_EmpIdAndCurrentIsTrue(emp.getEmpId());

        currentOpt.ifPresent(ed -> {
            ed.setCurrent(false);
            employeeDepartmentRepository.save(ed);
        });

        // Create new current assignment
        EmployeeDepartment newAssignment = new EmployeeDepartment(emp, dept, Instant.now(), true);
        employeeDepartmentRepository.save(newAssignment);
    }

    @Transactional(readOnly = true)
    public EmployeeResponse getEmployeeWithLatestDept(Long empId) {
        Employee emp = employeeRepository.findById(empId)
                .orElseThrow(() -> new IllegalArgumentException("Employee not found"));

        Optional<EmployeeDepartment> latest = employeeDepartmentRepository
                .findTopByEmployeeOrderByAssignedAtDesc(emp);

        return AppMapper.toEmployeeResponse(emp, latest);
    }
}
