package com.assessment.mid.dto;

import jakarta.validation.constraints.NotNull;

public class ChangeDepartmentRequest {
    @NotNull
    private Long departmentId;

    public Long getDepartmentId() { return departmentId; }
    public void setDepartmentId(Long departmentId) { this.departmentId = departmentId; }
}
