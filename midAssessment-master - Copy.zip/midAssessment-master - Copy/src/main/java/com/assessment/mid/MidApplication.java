package com.assessment.mid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MidApplication {

	public static void main(String[] args) {
		SpringApplication.run(MidApplication.class, args);
	}

}
