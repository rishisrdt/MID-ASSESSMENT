package com.assessment.mid.dto;

import java.util.ArrayList;
import java.util.List;

public class DepartmentResponse {
    private Long deptId;
    private String deptName;
    private List<EmployeeResponse> employees = new ArrayList<>(); // current employees

    public Long getDeptId() { return deptId; }
    public void setDeptId(Long deptId) { this.deptId = deptId; }
    public String getDeptName() { return deptName; }
    public void setDeptName(String deptName) { this.deptName = deptName; }
    public List<EmployeeResponse> getEmployees() { return employees; }
    public void setEmployees(List<EmployeeResponse> employees) { this.employees = employees; }
}
