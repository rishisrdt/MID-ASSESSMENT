package com.assessment.mid.controller;

import com.assessment.mid.dto.DepartmentCreateRequest;
import com.assessment.mid.dto.DepartmentResponse;
import com.assessment.mid.dto.EmployeeResponse;
import com.assessment.mid.service.DepartmentService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/departments")
public class DepartmentController {
    private final DepartmentService departmentService;
    public DepartmentController(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    // Add a department with employees
    @PostMapping
    public ResponseEntity<DepartmentResponse> create(@Valid @RequestBody DepartmentCreateRequest req) {
        return ResponseEntity.ok(departmentService.createDepartmentWithEmployees(req));
    }

    // Get all employees under a department (current only)
    @GetMapping("/{deptId}/employees")
    public ResponseEntity<List<EmployeeResponse>> getEmployees(@PathVariable Long deptId) {
        return ResponseEntity.ok(departmentService.getCurrentEmployeesInDepartment(deptId));
    }
}

