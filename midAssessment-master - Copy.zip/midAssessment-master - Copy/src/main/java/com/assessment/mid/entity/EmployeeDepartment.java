package com.assessment.mid.entity;

import jakarta.persistence.*;

import java.time.Instant;

@Entity
@Table(name = "employee_department")
public class EmployeeDepartment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Many assignments belong to one employee
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "emp_id", nullable = false)
    private Employee employee;

    // Many assignments belong to one department
    @ManyToOne(optional = false, fetch = FetchType.LAZY)
    @JoinColumn(name = "dept_id", nullable = false)
    private Department department;

    @Column(nullable = false, updatable = false)
    private Instant assignedAt;

    @Column(nullable = false)
    private boolean current;

    public EmployeeDepartment() {
    }

    public EmployeeDepartment(Employee employee, Department department, Instant assignedAt, boolean current) {
        this.employee = employee;
        this.department = department;
        this.assignedAt = assignedAt;
        this.current = current;
    }

    public Long getId() {
        return id;
    }

    public Employee getEmployee() {
        return employee;
    }

    public Department getDepartment() {
        return department;
    }

    public Instant getAssignedAt() {
        return assignedAt;
    }

    public boolean isCurrent() {
        return current;
    }

    public void setCurrent(boolean current) {
        this.current = current;
    }
}

